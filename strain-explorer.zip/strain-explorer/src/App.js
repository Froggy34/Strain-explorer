import React from "react";
import StrainSearch from "./components/StrainSearch";
import "./styles/global.css";

function App() {
  return (
    <div className="app-container">
      <h1>Strain Explorer 🌿</h1>
      <StrainSearch />
    </div>
  );
}

export default App;
